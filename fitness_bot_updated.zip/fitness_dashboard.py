
# (Python script content from previous step here)
